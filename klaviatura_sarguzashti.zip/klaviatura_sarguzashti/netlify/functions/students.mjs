import { getStore } from "@netlify/blobs";

const headers = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" };
const reply = (statusCode, data) => ({ statusCode, headers, body: JSON.stringify(data) });
const store = () => getStore("keyboard-students");

function authorized(event) {
  const expectedLogin = process.env.TEACHER_LOGIN;
  const expectedPassword = process.env.TEACHER_PASSWORD;
  if (!expectedLogin || !expectedPassword) return null;
  const value = event.headers.authorization || event.headers.Authorization || "";
  if (!value.startsWith("Basic ")) return false;
  let decoded;
  try { decoded = Buffer.from(value.slice(6), "base64").toString("utf8"); } catch { return false; }
  const split = decoded.indexOf(":");
  return split >= 0 && decoded.slice(0, split) === expectedLogin && decoded.slice(split + 1) === expectedPassword;
}

export default async (event) => {
  if (event.httpMethod !== "POST") return reply(405, { error: "Method not allowed" });
  let body;
  try { body = JSON.parse(event.body || "{}"); } catch { return reply(400, { error: "Invalid JSON" }); }

  if (body.action === "login" || body.action === "list" || body.action === "delete") {
    const auth = authorized(event);
    if (auth === null) return reply(503, { error: "Set TEACHER_LOGIN and TEACHER_PASSWORD in Netlify environment variables." });
    if (!auth) return reply(401, { error: "Unauthorized" });
  }

  const db = store();
  try {
    if (body.action === "login") return reply(200, { ok: true });
    if (body.action === "save") {
      const s = body.student;
      if (!s || typeof s.id !== "string" || typeof s.name !== "string" || s.id.length > 512 || s.name.length > 80) return reply(400, { error: "Invalid student record" });
      await db.setJSON(`student:${s.id}`, s);
      return reply(200, { ok: true });
    }
    if (body.action === "list") {
      const { blobs } = await db.list({ prefix: "student:" });
      const students = (await Promise.all(blobs.map(item => db.get(item.key, { type: "json" })))).filter(Boolean);
      return reply(200, { students });
    }
    if (body.action === "delete" && typeof body.id === "string") {
      await db.delete(`student:${body.id}`);
      return reply(200, { ok: true });
    }
    return reply(400, { error: "Unknown action" });
  } catch (error) {
    console.error("Student store request failed", error);
    return reply(500, { error: "Student data service unavailable" });
  }
};
